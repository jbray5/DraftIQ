# CLAUDE.md — DraftIQ frontend rebuild

You're rebuilding the frontend of **DraftIQ**, a live fantasy-football draft
command center with a **CRT phosphor terminal** aesthetic. This folder is a design
handoff from a high-fidelity prototype, not the app repo — read it, then build into
the real project.

## Read these first, in order
1. `reference/draftiq-prototype.html` — **the source of visual truth.** Open it in a
   browser. Match it. When this CLAUDE.md and the prototype disagree, the prototype
   wins on visuals.
2. `BUILD-SPEC.md` — intent, screen-by-screen component breakdown, interaction
   model, states, edge cases, and a suggested build order.
3. `design/tokens.css` + `design/tailwind.tokens.js` — every color, font, and the
   CRT overlay. Derive all styling from these; don't hardcode hex.
4. `data/types.ts` + `data/seed.json` — data contracts and seed data so the UI
   renders immediately, before any backend.

## Stack
Next.js + React + TypeScript + Tailwind unless the target repo says otherwise. UI
state is local for now; `seed.json` stands in for the live backend.

## Non-negotiables (these are the brief)
- **Keep the 3-layer CRT overlay** (scanlines + vignette + flicker). It's the
  atmosphere; don't drop it. Gate flicker/animation behind `prefers-reduced-motion`.
- **Monospace everything**; `tabular-nums` on every numeric column so stats align.
- **ANSI palette = meaning.** Amber is reserved for the recommendation / CTA /
  value — never decorative. Position colors are semantic (RB green · WR cyan ·
  QB red · TE amber · K/DST/IDP magenta); build one badge + one `posColor()` helper
  and reuse them everywhere.
- **TUI framing:** thin-bordered panels, uppercase letter-spaced headers, box-
  drawing dividers (`──── TIER 3 CLIFF ────`), the ASCII confidence meter
  (`[██████░░░░]`), zero panel border-radius.
- The status line and F-key bar persist across all three screens.

## Do / don't
- DO lift the small pure helpers from the prototype: `slotForPick`, `valueTag`, the
  confidence-meter and ASCII-bar string builders.
- DO treat the recommended pick, coach verdict, run-alerts, and grade as **outputs
  of services** to be wired later — the UI just needs the shapes in `types.ts`.
- DON'T invent a new visual direction or "modernize" away the terminal look.
- DON'T ship real player data as fact — it's illustrative placeholder; real data
  comes from the league/ESPN sync + projection model + coach (LLM) service.
- DON'T lose the quality floor: responsive collapse <~1100px, visible focus,
  Esc-closes-overlays, reduced motion, and a print stylesheet for the Cheat Sheet.

## Definition of done (frontend)
All three screens match the prototype; F-keys + click-to-draft + undo + coach drawer
+ popover work against seed data; tokens are the single source of styling; a11y and
print passes done; drag-a-row-onto-a-slot drafting implemented (click-to-draft
remains as fallback).
