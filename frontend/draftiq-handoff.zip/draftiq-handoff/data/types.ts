// =====================================================================
// DRAFTIQ — DATA CONTRACTS
// Keys are intentionally terse + tabular (they map 1:1 to the seed JSON
// and the prototype). Rename freely in the rebuild, but keep the seed
// JSON in sync if you do.
// =====================================================================

export type Position = "QB" | "RB" | "WR" | "TE" | "K" | "DST" | "IDP" | "FLEX";

/** A draftable player in the available pool / cheat sheet. */
export interface Player {
  rk: number;      // rank (positional in cheat sheet, board-rank in pool)
  nm: string;      // full display name
  tm: string;      // NFL team abbreviation
  pos: Position;
  proj: number;    // projected season points (half-PPR)
  vorp: number;    // value over replacement player
  adp: number;     // average draft position
  tier: number;
  bye: number;     // bye week
  note: string;    // one-line scouting note
  rec?: boolean;   // true for the single currently-recommended pick
  cls?: NoteClass; // optional note styling (cheat sheet only)
}

/** Note emphasis color in the cheat sheet NOTE column. */
export type NoteClass = "win" | "risk" | "val" | "cyan" | "";

/** One roster slot for the user's team. */
export interface RosterSlot {
  slot: string;             // "QB" | "RB1" | "RB2" | "WR1" | "WR2" | "TE" | "FLEX" | "IDP" | "DST" | "K"
  player: RosterPlayer | null;
  need: boolean;            // highlight as an active NEED when empty
}
export interface RosterPlayer {
  nm: string;
  tm: string;
  pos: Position;
  bye: number;
}

/** A pick already made on the live draft board. Keyed by overall pick #. */
export interface BoardPick {
  nm: string;     // abbreviated name e.g. "D.Achane"
  pos: Position;
  mine?: boolean; // true if it's the user's prior pick (gets ▲ marker)
}

/** Tier-cliff/break separator row inside a cheat-sheet position list. */
export interface TierBreak {
  t: number;        // the tier this row introduces
  cliff?: boolean;  // true = hard CLIFF (amber), false/undefined = soft BREAK (grey)
}

/** A cheat-sheet position list is an ordered mix of players and tier breaks. */
export type BigBoardRow = Player | TierBreak;
export type BigBoard = Record<Exclude<Position, "K" | "DST">, BigBoardRow[]>;

/** Post-draft positional bar-chart datum. */
export interface PosBar {
  pos: Position;
  you: number;  // your projected pts at this position group
  avg: number;  // league average
}

/** A finalized starting-lineup pick on the grade screen. */
export interface LineupPick {
  slot: string;
  nm: string;
  tm: string;
  pos: Position;
  rd: string;                                   // "round.pickInRound" e.g. "5.05"
  ov: number;                                   // overall pick number
  tag: "steal" | "value" | "fair" | "reach";    // per-pick value verdict
}

/** League standings projection row. */
export interface StandingRow {
  tm: string;
  pts: number;
  me?: boolean; // highlight the user's team
}

/** League/draft configuration. */
export interface LeagueConfig {
  name: string;       // "DEREK JETER'S TACO HOLE '25"
  teams: number;      // 12
  format: string;     // "HALF-PPR"
  rounds: number;     // 16
  mySlot: number;     // user's draft slot (1..teams)
  teamNames: string[];// length === teams, index 0 is the user
}

// Helper: snake-draft slot for a given overall pick (1-indexed).
export function slotForPick(pick: number, teams = 12): number {
  const round = Math.ceil(pick / teams);
  const inRound = pick - (round - 1) * teams;
  return round % 2 === 0 ? teams + 1 - inRound : inRound;
}

// Helper: value verdict vs current pick.
export function valueTag(adp: number, currentPick: number) {
  const d = adp - currentPick;
  if (d >= 8) return { delta: `+${d}`, word: "STEAL", tone: "amber" as const };
  if (d > 0)  return { delta: `+${d}`, word: "VALUE", tone: "amber" as const };
  if (d === 0)return { delta: "0",     word: "FAIR",  tone: "dim"   as const };
  return        { delta: `${d}`,       word: "REACH", tone: "risk"  as const };
}
