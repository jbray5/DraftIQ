/**
 * DRAFTIQ — Tailwind token map
 * Merge into tailwind.config.{js,ts} -> theme.extend.
 * Mirrors design/tokens.css so you can use either CSS vars or Tailwind classes.
 * Position colors are intentionally semantic — class names encode meaning.
 */
module.exports = {
  theme: {
    extend: {
      colors: {
        bg:          "#05060A",
        "bg-panel":  "#070B09",
        "bg-header": "#040805",
        "bg-status": "#020403",

        phosphor:    "#33FF66", // base text + RB
        "phosphor-dim": "#1f8a44",
        dim:         "#5c7a66",
        "dim-dk":    "#37463c",
        bright:      "#E8FFE8",

        // ANSI semantic accents
        amber:   "#FFB000", // recommendation / CTA / TE
        risk:    "#FF5555", // risk / QB / below-avg
        info:    "#22D3EE", // info / VORP / WR
        magenta: "#FF77FF", // K / DST / IDP

        line:        "#15351f",
        "line-bright": "#236b38",

        // position map (alias the above for readability in JSX)
        "pos-rb":  "#33FF66",
        "pos-wr":  "#22D3EE",
        "pos-qb":  "#FF5555",
        "pos-te":  "#FFB000",
        "pos-k":   "#FF77FF",
        "pos-dst": "#FF77FF",
        "pos-idp": "#E8FFE8",
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', "ui-monospace", '"Courier New"', "monospace"],
        crt:  ['"VT323"', '"JetBrains Mono"', "monospace"],
      },
      fontVariantNumeric: ["tabular-nums"], // remember to add `tabular-nums` on stat rows
      boxShadow: {
        glow:       "0 0 4px currentColor, 0 0 11px rgba(51,255,102,.35)",
        "glow-amber":"0 0 5px #FFB000, 0 0 16px rgba(255,176,0,.45)",
        clock:      "0 0 14px rgba(255,176,0,.55)",
      },
      keyframes: {
        blink:   { "50%": { opacity: "0" } },
        flicker: { "0%": { opacity: ".55" }, "50%": { opacity: ".18" }, "100%": { opacity: ".55" } },
        scroll:  { from: { transform: "translateX(0)" }, to: { transform: "translateX(-100%)" } },
        clockglow:{ from:{ boxShadow:"0 0 4px rgba(255,176,0,.25)" }, to:{ boxShadow:"0 0 14px rgba(255,176,0,.55)" } },
      },
      animation: {
        blink:     "blink 1s steps(1) infinite",
        flicker:   "flicker .14s infinite steps(2)",
        ticker:    "scroll 26s linear infinite",
        clockglow: "clockglow 1s ease-in-out infinite alternate",
      },
    },
  },
};

/* Fonts: add to your layout <head> or next/font:
   https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700;800&family=VT323&display=swap
*/
