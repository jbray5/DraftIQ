# DraftIQ — frontend handoff

A design handoff for rebuilding the **DraftIQ** draft command center (CRT phosphor
terminal aesthetic, 3 screens) in the real app.

## Contents
```
draftiq-handoff/
├── README.md                         ← you are here
├── CLAUDE.md                         ← agent context — point Claude Code at this first
├── BUILD-SPEC.md                     ← full design + component + interaction spec
├── reference/
│   └── draftiq-prototype.html        ← source of visual truth (open in a browser)
├── design/
│   ├── tokens.css                    ← colors, fonts, CRT overlay (framework-agnostic)
│   └── tailwind.tokens.js            ← same tokens as a Tailwind theme extension
└── data/
    ├── types.ts                      ← TypeScript data contracts + helpers
    └── seed.json                     ← seed data so the UI renders without a backend
```

## How to use with Claude Code

1. Drop this folder into (or beside) your DraftIQ repo.
2. From the repo, point the agent at the handoff, e.g.:

   > Read `draftiq-handoff/CLAUDE.md`, then `BUILD-SPEC.md`, then open
   > `reference/draftiq-prototype.html`. Rebuild these three screens in our
   > Next.js/Tailwind app, using `design/tokens.css` for styling and
   > `data/seed.json` for placeholder data. Start with the app shell + CRT overlay,
   > then Screen 1.

3. Build in the order suggested at the end of `BUILD-SPEC.md`. The prototype is the
   visual reference — match it, then wire your real data sources in place of the
   seed.

## Notes
- All player data, projections, opponent names, and the grade are **placeholder**.
  Wire the real league/ESPN sync, projection/VORP model, and coach (LLM) service
  behind the same shapes in `types.ts`.
- The prototype's two known gaps to finish in the rebuild: **drag-a-row-onto-a-slot**
  drafting (currently click-to-draft) and **auto-advancing opponent picks** so a full
  mock can run end-to-end.
