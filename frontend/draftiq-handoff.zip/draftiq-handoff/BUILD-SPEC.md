# DraftIQ — Frontend Build Spec

A rebuild brief for the **DraftIQ** live fantasy-football draft command center.
Aesthetic: **CRT phosphor terminal** (a Bloomberg terminal that happens to draft
fantasy football). Desktop-first. Three screens.

The companion file `reference/draftiq-prototype.html` is the **source of visual
truth** — open it in a browser and match it. This spec captures intent, structure,
states, and edge cases so the rebuild doesn't drift.

---

## 0. Stack assumption

Built for **Next.js + React + TypeScript + Tailwind** (your usual). If you're
targeting something else, the tokens (`design/tokens.css`) and contracts
(`data/types.ts`) are framework-agnostic — adapt the component notes accordingly.
State is local/UI state for now; the seed data (`data/seed.json`) stands in for
the live backend.

---

## 1. Aesthetic system (do not compromise these)

- **Everything monospace.** Body/tables = JetBrains Mono. Big display (the grade
  letter) = VT323. Always `tabular-nums` on any numeric column so stats align.
- **Near-black `#05060A`** background with the **3-layer CRT overlay** mounted
  above all content: scanlines (multiply blend), radial vignette, subtle flicker.
  This is the atmosphere — keep it. Gate the flicker behind
  `prefers-reduced-motion`.
- **ANSI palette = meaning, not decoration.** Phosphor green is the base voice.
  Amber is reserved for *the recommendation / CTA / value*. Red = risk/QB. Cyan =
  info/VORP/WR. Magenta = K/DST/IDP. Don't reach for amber decoratively — it
  should always mean "look here / this is the move."
- **Position color map is semantic and global:** RB green · WR cyan · QB red ·
  TE amber · K/DST/IDP magenta. Build one `<PosBadge pos>` and one `posColor()`
  helper; use them everywhere (board chips, tables, roster, lineup, bars).
- **TUI framing.** Panels are thin-bordered boxes with an uppercase header bar
  (letter-spaced) and an optional blinking block cursor `▋`. Section dividers and
  the confidence meter use box-drawing/block glyphs (`──── TIER 3 CLIFF ────`,
  `[██████░░░░]`). Zero border-radius on panels (the app shell has a soft radius
  only to read as a "screen").
- **Persistent chrome:** a top **status line** (league · ROUND x/PICK n · live
  `draftiq>` prompt · on-the-clock timer) and a bottom **F-key bar**
  (F1 SEARCH · F2 COACH · F3 CHEATSHEET · F4 COMMAND · F5 REFRESH · F6 GRADE ·
  ⌫ UNDO). These stay mounted across all screens.

---

## 2. App shell / layout

```
┌───────────────────────────────────────────────── status line (fixed) ─┐
│ DRAFTIQ │ league │ ROUND 5/PICK 53 │ draftiq> _ │        ON CLOCK 01:14 │
├──────────────────────────────────────────────────────── top nav tabs ──┤
│ [F4 DRAFT COMMAND] [F3 CHEAT SHEET] [F6 POST-DRAFT GRADE]                │
├─────────────────────────────────────────────────────────── <main> ─────┤
│   one of three <Screen> components renders here (scrollable)            │
├──────────────────────────────────────────────────────── F-key bar ─────┤
│ F1 SEARCH · F2 COACH · F3 CHEATSHEET · F4 COMMAND · F5 REFRESH · ⌫ UNDO │
└─────────────────────────────────────────────────────────────────────────┘
+ CRT overlays (fixed, pointer-events:none, top z) + Coach drawer + Popover
```

Suggested component tree:

```
<AppShell>
  <CrtOverlay/>                  // 3 fixed layers
  <StatusLine/>                  // reads LeagueConfig + clock + current pick
  <TopNav active onChange/>
  <main>
    <DraftCommand/> | <CheatSheet/> | <PostDraftGrade/>
  </main>
  <FKeyBar onAction/>
  <CoachDrawer open target onClose onDraft/>
  <PlayerPopover player anchor onClose .../>
</AppShell>
```

Screen switching is driven by both the nav tabs and the F-keys (§6). Keep one
`screen` state at the shell.

---

## 3. SCREEN 1 — Draft Command Center (the hero)

Three stacked zones plus a right-side drawer.

### 3a. Run-alert ticker
Full-width amber-bordered marquee. Left chip `⚠ RUN ALERT`, then a horizontally
scrolling track of `runAlerts[]` joined by `●` separators. Risk phrases inside
("tier cliff after Daniels") render red. Pause/disable scroll under reduced motion.

### 3b. Draft board strip
Compact **12-column snake grid** of recent picks. Render rounds 3–5 (config:
`ROUNDS_SHOWN`). Column headers = team names (the user's column flagged amber with
`▲`). Each cell is a **chip**: overall pick #, abbreviated name, position code in
its position color.
- The **on-the-clock** cell (overall === `currentPick`) glows amber with a pulsing
  box-shadow and shows the user + `ON CLOCK`.
- The user's own prior picks get a `▲` and a green border.
- Empty future cells are dimmed `·`.
- Snake direction: odd rounds L→R, even rounds R→L. Use `slotForPick()` from
  `types.ts`; the user is at `mySlot` (5).

### 3c. Decision zone (2-up grid)
**Left — `▶ RECOMMENDED PICK` card** (amber-framed, the single loudest element):
- Big player name (white, glow), then `team · POS badge · TIER · BYE`.
- Right-aligned **value tag**: big amber delta (`+9`) + `STEAL/VALUE VS ADP`
  (compute with `valueTag(adp, currentPick)`).
- 4-cell stat grid: PROJ · VORP · ADP · FILLS (the need it satisfies).
- **ASCII confidence meter**: `[██████░░░░] 62%` (filled = round(pct/10)).
- Footer: `[ DRAFT <name> ]` (amber, primary) + `ASK COACH` (ghost).

**Right — AI Coach verdict panel:**
- Big `[ DRAFT ]` / `[ PASS ]` tag (green / red, letter-spaced, glow).
- 2 pros (green `▸`), 1 risk (red `▲`), each one short line.

The recommended player is `availablePool.find(p => p.rec)`.

### 3d. Bottom split (2-up grid)
**Left (wider) — Available Players pool:**
- Sticky filter row: position pills (`ALL RB WR QB TE K DST IDP`) + a
  terminal-style `/search` input. Active pill fills with its position color.
- Terminal table, columns: `RANK · NAME · POS · PROJ · VORP · ADP · TIER · BYE ·
  VAL · ACTION`. Right-align all numerics, `tabular-nums`. Position-colored badges.
  VAL column uses `valueTag`. The recommended row is faintly amber-tinted with a
  `▶` rank marker.
- When filtered to a single position, insert tier-divider rows
  (`──── RB TIER 4 ────`) between tier changes.
- Per-row hover reveals `[DRAFT]` (amber) and `[ASK]` (cyan) mini-buttons.
- Row click (not on a button) → **PlayerPopover** anchored at the cursor.

**Right — My Roster:**
- `NEED:` line (dashed amber) listing empty `need` slots + a QB-cliff note when QB
  is unfilled. When starters are all filled, switch to a green
  "✓ STARTERS SET · build bench depth".
- Slot list from `rosterTemplate`. Filled slots: `SLOT · name · team · BYE n`
  (bye highlighted amber when it collides with the configured bye-stack week).
  Empty slots dimmed; `need` slots tinted amber. Bench section appears once bench
  fills.

### 3e. AI Coach drawer (slide-in, right)
Rendered as a **terminal session log**, not a card:
- Timestamped lines: `[hh:mm:ss] jray> ask coach: <name>?` then
  `coach> analyzing …`.
- A log block with the verdict tag, `▸ WHY` (pros, green `+`), `▲ RISK`
  (red `!`), `⇄ ALTERNATIVES` (amber `→`, 2 picks of a different position).
- An **opponent-tendency** footer referencing rivals by name (e.g. Spivey reaches
  for QBs early; Zero RB Zealot hoards WRs). Pull names from `teamNames`.
- Footer actions: `[ DRAFT <name> ]` + `ALTERNATIVES` (re-targets the drawer).
- A scrim behind it; Esc and scrim-click close.

---

## 4. SCREEN 2 — Pre-Draft Cheat Sheet (printable)

A dense tiered **big board** as a terminal report; should print cleanly.

- **Report header:** `DRAFTIQ // 2025 CHEAT SHEET` · `HALF-PPR · 12-TEAM · SNAKE`
  · `GENERATED hh:mm · v…`.
- **Left rail:** position tabs (`RB WR QB TE FLEX`) with counts, plus a
  **BY POS / OVERALL** toggle.
- **Big board table:** `★ · RK · NAME · TM · BYE · PROJ · VORP · ADP · T · NOTE`.
  - Players grouped into tiers; insert a horizontal divider between tiers —
    **hard cliffs** amber (`──── TIER 3 CLIFF ────`), soft breaks grey
    (`──── TIER 2 BREAK ────`). Source: `bigBoard[pos]` is an ordered array mixing
    player rows and `{t, cliff}` separator rows.
  - NOTE column is color-keyed by `cls`: `win`→amber, `risk`→red, `val`→green,
    `cyan`→cyan, else grey-italic.
  - OVERALL view: flatten all positions, drop separators, sort by ADP, take top ~40.
- **Right rail — TARGETS / AVOID pin lists.** Clicking a row's `★` cycles
  **none → target (★ amber) → avoid (⊘ red) → none**. Pinned names list in the
  rails with a remove `✕`. Seed with a few targets/avoids.

---

## 5. SCREEN 3 — Post-Draft Grade (report card)

- **Grade box:** huge VT323 letter grade (amber, heavy glow), `TEAM GRADE · JRAY`
  label, `PROJ FINISH · 2nd of 12`.
- **Report card panel:** green verdict line + a short paragraph summary.
- **Positional breakdown:** ASCII bar chart. For each `bars[]` row render a bar of
  block chars scaled to the max, with a `┊` marker at the league-avg position and a
  `<you>/<avg>` readout. Rows where `you < avg` render the bar **red** (below
  average). Include a small legend.
- **Standings projection:** ranked `standings[]`, the user's row highlighted amber
  with `◄ YOU`.
- **Starting lineup table:** `SLOT · PLAYER · POS · TM · ROUND · OVR · VALUE` with
  per-pick value tag (`STEAL ★` amber / `VALUE` green / `FAIR` grey / `REACH` red).
- **Strengths (green) / Weaknesses · bye stacks (red)** bullet lists.
- **AI Coach closing log:** amber-framed panel, the coach's "how you win from here"
  entry (waiver/trade angles), signed off as a closed session.

---

## 6. Interaction model

- **Screen nav:** nav tabs + F-keys. `F1`→focus search (on Command screen),
  `F2`→open Coach on the recommended pick, `F3`→Cheat Sheet, `F4`→Command,
  `F5`→refresh (toast), `F6`→Grade, `⌫`/Backspace→Undo last pick, `Esc`→close
  drawer/popover. Wire both the clickable F-key bar and real `keydown`.
- **Draft a player** (rec button, row `[DRAFT]`, popover, or drawer):
  1. Remove from `availablePool`.
  2. Place into the best open slot by position priority
     (RB→RB2,RB1,FLEX · WR→WR2,WR1,FLEX · TE→TE,FLEX · else its own slot), else bench.
  3. Clear that slot's `need`; recompute the `NEED:` line.
  4. Promote the next-best pool player that fills a remaining need (else top of pool)
     to `rec`.
  5. Re-render board/roster/rec; flash a status toast.
  - **Intended (not yet built): drag a player row onto a roster slot to draft.**
    Implement with pointer/drag events; the click-to-draft path above is the
    fallback and should remain.
- **Undo/redo:** keep a pick history stack so `⌫` reverses the last draft
  (re-insert into pool, clear slot, restore prior rec). (Prototype stubs this.)
- **Popover:** player detail with full stat grid + scout note + `[DRAFT]`/`ASK`.
  Closes on outside click / Esc; clamp position to viewport.
- **Timer:** counts down from ~90s; turns red ≤15s; loops for the demo. In the real
  app this binds to the live draft clock.

---

## 7. Data & what's mocked

- Contracts: `data/types.ts`. Seed: `data/seed.json` (faithful export of the
  prototype's state). Keys are terse/tabular by design; rename if you prefer, but
  keep seed + types in sync.
- **Everything is placeholder.** Player names, 2025 projections, ADP, VORP, tiers,
  notes, opponent names, and the grade are illustrative. In the real app these come
  from your league source (ESPN sync) + your projection/VORP model + the coach
  (LLM) service. Treat `rec`, the coach verdict, run-alerts, and the grade as
  **outputs of services** you'll wire later — the UI just needs the shapes.
- Helpers worth lifting as-is: `slotForPick`, `valueTag`, the confidence-meter
  string builder, and the ASCII-bar builder (see prototype `renderBars`).

---

## 8. Quality floor

- Responsive: the 2-up grids collapse to single column under ~1100px (see prototype
  media query). It's desktop-first but shouldn't break on a laptop/tablet.
- Keyboard: visible focus ring (amber), F-keys real, Esc closes overlays, drawer is
  focus-trapped.
- Motion: `prefers-reduced-motion` kills flicker/ticker/blink/glow animations.
- Print: Cheat Sheet should `@media print` to ink-friendly monochrome (the terminal
  greens read fine on screen; give it a print stylesheet so it's usable on paper).

---

## 9. Suggested build order

1. Tokens + CRT overlay + AppShell (status line, nav, F-key bar) — get the *frame*
   and the atmosphere first.
2. `PosBadge` + table primitives + the seed data wired through a small store.
3. Screen 1 zones top-to-bottom: board → decision → bottom split. Then the drawer
   and popover.
4. Screen 2 (reuses table primitives + tier dividers).
5. Screen 3 (bar chart + tables).
6. Interactions: F-keys, draft flow, undo stack, then drag-to-draft.
7. A11y + print pass.
